import { type QueryClient, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import type { CreateRecipeDto, Recipe } from "@recipe/common";

import { recipeApi } from "./api";
import { filterRecipes } from "./lib/filterRecipes";
import type { GetRecipesProps } from "./types";

export const RECIPE_KEYS = {
    all: ["recipes"] as const,
    lists: () => [...RECIPE_KEYS.all, "list"] as const,
    list: (filters: GetRecipesProps) =>
        [...RECIPE_KEYS.lists(), filters] as const,
    detail: (id: string) => [...RECIPE_KEYS.all, "detail", id] as const,
    categories: () => [...RECIPE_KEYS.all, "categories"] as const,
};

// Ключи списков тегов и категорий: у них есть счётчик рецептов, его нужно обновлять после изменений рецептов
const TAGS_KEY = ["tags"] as const;
const CATEGORIES_KEY = ["categories"] as const;

// После добавления и удаления рецепта открывается главная. Если перейти сразу, она покажет старый список
// из кэша, а через мгновение новый, и список моргнёт. Поэтому mutation ждёт свежие списки (onSuccess возвращает
// промис), и только потом срабатывает переход. refetchType "all": главная ещё не открыта, её список неактивен
const refetchRecipeLists = (queryClient: QueryClient) =>
    queryClient.invalidateQueries({ queryKey: RECIPE_KEYS.lists(), refetchType: "all" });

export function useRecipes(filters: GetRecipesProps) {
    const queryClient = useQueryClient();
    const getAll = () => queryClient.getQueryData<Recipe[]>(RECIPE_KEYS.list({}));

    return useQuery({
        queryKey: RECIPE_KEYS.list(filters ?? {}),
        queryFn: () => recipeApi.getAll(filters),
        // Пока грузится новый список, сразу показываем его же, отобранный из уже загруженного полного списка
        // (те же условия, что у сервера): сетка не задерживается на прежнем фильтре. Полного списка нет — прежний
        placeholderData: (previous) => {
            const all = getAll();
            return all ? filterRecipes(all, filters) : previous;
        },
    });
}

export function useRecipe(id: string) {
    return useQuery({
        queryKey: RECIPE_KEYS.detail(id),
        queryFn: () => recipeApi.getById(id),
        enabled: !!id,
    });
}

export function useCreateRecipe() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (recipe: CreateRecipeDto) => recipeApi.create(recipe),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: RECIPE_KEYS.categories() });
            queryClient.invalidateQueries({ queryKey: TAGS_KEY });
            queryClient.invalidateQueries({ queryKey: CATEGORIES_KEY });
            return refetchRecipeLists(queryClient);
        },
    });
}

export function useUpdateRecipe() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: ({ id, ...data }: Partial<CreateRecipeDto> & { id: string }) =>
            recipeApi.update(id, data),
        onSuccess: (_, { id }) => {
            queryClient.invalidateQueries({ queryKey: RECIPE_KEYS.lists() });
            queryClient.invalidateQueries({ queryKey: RECIPE_KEYS.detail(id) });
            queryClient.invalidateQueries({ queryKey: TAGS_KEY });
            queryClient.invalidateQueries({ queryKey: CATEGORIES_KEY });
        },
    });
}

export function useDeleteRecipe() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (id: string) => recipeApi.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: TAGS_KEY });
            queryClient.invalidateQueries({ queryKey: CATEGORIES_KEY });
            return refetchRecipeLists(queryClient);
        },
    });
}

export function useUploadMedia() {
    return useMutation({
        mutationFn: (file: File) => recipeApi.uploadMedia(file),
    });
}