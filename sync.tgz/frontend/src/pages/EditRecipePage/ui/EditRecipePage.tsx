import { useTranslation } from "react-i18next";
import { useNavigate, useParams } from "react-router-dom";

import { AppRoute, buildRoute } from "@/app/router/routes";
import { useRecipe, useUpdateRecipe } from "@/entities/recipe";
import { EMPTY_FORM_VALUES, getCover, getVideo, RecipeForm, type RecipeFormValues, toMedia } from "@/features/recipe-form";
import { ApiError } from "@/shared/api";
import { useLoader } from "@/shared/ui/GlobalLoader";
import { LoadErrorMessage, Message } from "@/shared/ui/Message";
import { PageWrapper } from "@/shared/ui/PageWrapper";

const EditRecipePage = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const { t } = useTranslation(["recipeForm", "recipe", "footer"]);

    const { data: recipe, isLoading, error, isFetching, refetch } = useRecipe(id!);
    useLoader(isLoading || (!recipe && isFetching));
    const { mutate: updateRecipe, isPending } = useUpdateRecipe();

    if (isLoading) return null;
    // 404 — рецепта нет. Другая ошибка или нет сети — рецепт есть, но не загрузился
    if (!recipe) {
        return (
            <PageWrapper>
                {error instanceof ApiError && error.status === 404 ? (
                    <Message illustration="warning" title={t("recipe:notFound.title")} text={t("recipe:notFound.text")} />
                ) : (
                    <LoadErrorMessage onRetry={() => refetch()} />
                )}
            </PageWrapper>
        );
    }

    const handleSubmit = (values: RecipeFormValues) => {
        updateRecipe(
            {
                id: recipe.id,
                title: values.title,
                description: values.description?.trim() || null,
                categoryId: values.categoryId,
                ingredients: values.ingredients,
                steps: values.steps,
                prepTime: values.prepTime ?? null,
                cookTime: values.cookTime ?? null,
                servings: values.servings ?? null,
                calories: values.calories ?? null,
                protein: values.protein ?? null,
                fat: values.fat ?? null,
                carbs: values.carbs ?? null,
                tags: values.tagIds,
                media: toMedia(values.cover, values.video),
            },
            { onSuccess: () => navigate(buildRoute.recipe(recipe.id)) }
        );
    };

    return (
        <PageWrapper>
            <RecipeForm
                title={t("form.editTitle")}
                subtitle={recipe.title}
                breadcrumbs={[
                    { label: t("footer:collection"), to: AppRoute.Home },
                    { label: recipe.title, to: buildRoute.recipe(recipe.id) },
                    { label: t("form.editTitle") },
                ]}
                defaultValues={{
                    title: recipe.title,
                    description: recipe.description,
                    categoryId: recipe.categoryId,
                    // Рецепт без ингредиентов или шагов: в форме одна пустая строка, как в новом
                    ingredients: recipe.ingredients.length > 0 ? recipe.ingredients : EMPTY_FORM_VALUES.ingredients,
                    steps: recipe.steps.length > 0 ? recipe.steps : EMPTY_FORM_VALUES.steps,
                    prepTime: recipe.prepTime,
                    cookTime: recipe.cookTime,
                    servings: recipe.servings ?? undefined,
                    calories: recipe.calories,
                    protein: recipe.protein,
                    fat: recipe.fat,
                    carbs: recipe.carbs,
                    tagIds: recipe.tags.map((t) => t.tagId),
                    cover: getCover(recipe.media),
                    video: getVideo(recipe.media),
                }}
                onSubmit={handleSubmit}
                isPending={isPending}
                submitLabel={t("submitEdit")}
            />
        </PageWrapper>
    );
};

export default EditRecipePage;