import { useState } from "react";
import { useTranslation } from "react-i18next";

import type { Tag } from "@recipe/common";

import { buildRoute } from "@/app/router/routes";
import { TagForm, TagItem, useDeleteTag, useTags } from "@/entities/tag";
import { BottomSheet } from "@/shared/ui/BottomSheet";
import { AddTile } from "@/shared/ui/Buttons";
import { LoadErrorMessage } from "@/shared/ui/Message";
import { ConfirmModal } from "@/shared/ui/Modal";
import { Spinner } from "@/shared/ui/Spinner";

import { SectionsLayout } from "../SectionsLayout/SectionsLayout";

import styles from "./TagsTab.module.scss";

export function TagsTab() {
    const { t } = useTranslation("sections");
    const { data, isLoading, isError, isPaused, isFetching, refetch } = useTags();
    const tags = data ?? [];
    // Список не пришёл (сервер не ответил или нет сети): вместо пустого раздела — ошибка и «Повторить»
    const isFailed = !data && (isError || isPaused);
    const { mutate: remove } = useDeleteTag();

    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingTag, setEditingTag] = useState<Tag | null>(null);

    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const [deletingTag, setDeletingTag] = useState<Tag | null>(null);

    const openCreate = () => {
        setEditingTag(null);
        setIsFormOpen(true);
    };

    const openEdit = (tag: Tag) => {
        setEditingTag(tag);
        setIsFormOpen(true);
    };

    const closeForm = () => setIsFormOpen(false);

    const askDelete = (tag: Tag) => {
        setDeletingTag(tag);
        setIsConfirmOpen(true);
    };

    const closeConfirm = () => setIsConfirmOpen(false);

    const confirmDelete = () => {
        if (deletingTag) remove(deletingTag.id);
        closeConfirm();
    };

    if (isLoading || (isFailed && isFetching)) return <Spinner size="md" />;
    if (isFailed) return <LoadErrorMessage onRetry={() => refetch()} />;

    return (
        <>
            <SectionsLayout createTitle={t("create.tags.title")} createText={t("create.tags.text")} onCreate={openCreate}>
                <div className={styles.list}>
                    <AddTile className={styles.add} label={t("tags.add")} onClick={openCreate} />
                    {tags.map((tag, index) => (
                        <TagItem
                            key={tag.id}
                            tag={tag}
                            colorIndex={index}
                            to={buildRoute.homeByTag(tag.id)}
                            onEdit={openEdit}
                            onDelete={askDelete}
                        />
                    ))}
                </div>
            </SectionsLayout>

            <BottomSheet
                isOpen={isFormOpen}
                onClose={closeForm}
                title={editingTag ? t("editing") : t("tags.add")}
            >
                <TagForm
                    key={editingTag?.id ?? "new"}
                    tag={editingTag}
                    onSuccess={closeForm}
                    onCancel={closeForm}
                />
            </BottomSheet>

            <ConfirmModal
                isOpen={isConfirmOpen}
                onClose={closeConfirm}
                onConfirm={confirmDelete}
                title={t("tags.deleteTitle", { name: deletingTag?.name })}
                text={t("tags.deleteText")}
            />
        </>
    );
}
