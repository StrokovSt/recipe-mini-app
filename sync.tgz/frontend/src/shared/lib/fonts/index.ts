export { loadFonts } from "./loadFonts";
